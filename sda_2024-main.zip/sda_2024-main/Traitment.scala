trait Traitement {

  def action = " i do something "

}
