abstract  class Moteur {
  val marque:String
  val moteurType="auto"

  def coucou()="na ga def"

  def auther(a:Int):Int

}
