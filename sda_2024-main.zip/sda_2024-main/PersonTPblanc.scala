case class Person(age:Int, rattrapage:Int)
