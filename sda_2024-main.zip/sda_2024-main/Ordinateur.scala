case class Ordinateur(marque:String)
