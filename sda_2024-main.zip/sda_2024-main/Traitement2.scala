abstract class Traitement2 { def action = " i do something "}
